declare module "@salesforce/apex/AccountlistviewController.fetchRecs" {
  export default function fetchRecs(param: {listValues: any}): Promise<any>;
}
declare module "@salesforce/apex/AccountlistviewController.getDependentMap" {
  export default function getDependentMap(param: {objDetail: any, contrfieldApiName: any, depfieldApiName: any}): Promise<any>;
}
