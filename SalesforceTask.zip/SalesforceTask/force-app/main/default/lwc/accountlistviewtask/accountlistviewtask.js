import { api, LightningElement, track, wire } from 'lwc';  
import fetchRecs from '@salesforce/apex/AccountlistviewController.fetchRecs';   
import { NavigationMixin } from 'lightning/navigation';
export default class Accountlistviewtask extends NavigationMixin( LightningElement ) {  
    isLoading =true;
    @track listRecs;  
    //@track initialListRecs;
    @track error;  
    @track columns;  
     SearchKey;
    @api ObjectAPIName='Account';
    @api Fields='Name, NumberOfEmployees, Owner.Name, Site, AnnualRevenue';
    @api SearchByfieldName='Name';
    @api TableColumns;
    @api Title;
     country;
     state;
    sortedBy;
    defaultSortDirection = 'asc';
    sortDirection = 'asc';

    get vals() {  

        return this.ObjectAPIName + '-' + this.Fields + '-' +   
               this.SearchByfieldName + '-' + this.SearchKey+'-'+this.country+'-'+this.state;  

    }

    connectedCallback() {

        this.columns =[{label:'Name',fieldName:'Name' }, {label:'AccountSite',fieldName: 'Site'},{ label:'Account Owner',fieldName:'Owner_Name'},{label:'AnnualRevenue', fieldName:'AnnualRevenue'}, {label:'NumberOfEmployees', fieldName:'NumberOfEmployees'}];// JSON.parse( this.TableColumns.replace( /([a-zA-Z0-9]+?):/g, '"$1":' ).replace( /'/g, '"' ) );

        this.handleSearch();

    }

    

    handleSearch() {
        fetchRecs({ listValues: this.vals })
            .then((result) => {
              this.error = undefined;
                let  Owner_Name;
                this.listRecs = result.map(row => { 
                    Owner_Name =row.Owner.Name;// `/${row.Id}`;
                    return {...row , Owner_Name} 
                }); 
    
                this.isLoading=false;
                //this.initialListRecs = result;
            })
            .catch((error) => {
                this.isLoading=false;
                this.error = error;
                this.contacts = undefined;
            });
    }


    @api handleValueChange(selectedcountry,selectedState) {
        console.log('country child-----',selectedcountry);
        console.log('selectedStatechild-----',selectedState);
       // this.selectedcountry,this.selectedState
        this.country =selectedcountry;
        this.state =selectedState;
           this.handleSearch();
      }


    handleKeyChange( event ) { 
        this.SearchKey=event.target.value; 
        console.log('searchkey',this.SearchKey);
        this.handleSearch();
    }


}