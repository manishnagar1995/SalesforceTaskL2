import { LightningElement ,wire,track,api} from 'lwc';
import countryStateValues from '@salesforce/apex/AccountlistviewController.getDependentMap';  

export default class FilterComponentTask extends LightningElement {
 error;
 @track countryList=[];
 @track stateList=[];
 @track selectedcountry='';
 @track selectedState='';
 conStMap=[];
  @wire(countryStateValues)  
        wiredRecs( { error, data } ) {
          if ( data ) {
            this.conStMap =data;
                let parentField = []; // for store parent picklist value to set on lightning:select.
               for (let pickKey in  data) {

                   parentField.push({
                       'label': pickKey,
                       'value': pickKey
                   });
               }
               this.countryList=parentField;
               console.log( 'parentField---' , JSON.stringify( this.countryList) );
              
            } else if ( error ) {
                this.error = error;
            }

        }


        handleChange(event){
            let selectedvalues = event.detail.value;
            if(event.target.dataset.id === 'Country'){
                this.selectedcountry = selectedvalues;
                this.stateList =[];
                console.log('country-----',this.selectedcountry);//country={selectedcountry}  state={selectedState}
                this.template.querySelector("c-accountlistviewtask").handleValueChange(this.selectedcountry,this.selectedState);
                let statearr =[];
                for(let key in this.conStMap[this.selectedcountry] ){
                    statearr.push({
                        'label': key,
                        'value': key,
                    });
                }
                this.stateList=statearr;
            
            }else if(event.target.dataset.id === 'State'){
                this.selectedState = selectedvalues;
                this.template.querySelector("c-accountlistviewtask").handleValueChange(this.selectedcountry,this.selectedState);
            }
           
           

            
        }
}